#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using System.IO;

[InitializeOnLoad]
public static class BackroomsProjectSetup
{
    static BackroomsProjectSetup(){ EditorApplication.delayCall += EnsureProject; }
    static void EnsureProject(){
        Directory.CreateDirectory("Assets/Settings");
        var urp = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>("Assets/Settings/BackroomsURP.asset");
        if(urp==null){
            var renderer = UniversalRendererData.CreateInstance<UniversalRendererData>();
            renderer.name="BackroomsRenderer";
            AssetDatabase.CreateAsset(renderer,"Assets/Settings/BackroomsRenderer.asset");
            var asset = UniversalRenderPipelineAsset.Create(renderer);
            asset.name="BackroomsURP";
            asset.supportsHDR=true; asset.msaaSampleCount=4; asset.renderScale=1f;
            AssetDatabase.CreateAsset(asset,"Assets/Settings/BackroomsURP.asset");
            GraphicsSettings.defaultRenderPipeline=asset; QualitySettings.renderPipeline=asset;
            AssetDatabase.SaveAssets(); AssetDatabase.Refresh();
        }
        if(!File.Exists("Assets/Scenes/Level0.unity")) CreateScene();
    }
    static void CreateScene(){
        var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
        var go=new GameObject("GAME_BOOTSTRAP"); go.AddComponent<BackroomsBootstrap>();
        EditorSceneManager.SaveScene(scene,"Assets/Scenes/Level0.unity");
        EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/Scenes/Level0.unity",true)};
    }
}
#endif

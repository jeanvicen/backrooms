using UnityEngine;

public class GameUI : MonoBehaviour
{
    static string message=""; static float messageTimer; GUIStyle title,small,bar; PlayerController p; SanitySystem s; InventorySystem inv;
    void Start(){ var b=FindObjectOfType<BackroomsBootstrap>(); p=b.Player;s=b.Sanity;inv=b.Inventory; }
    public static void ShowMessage(string m){message=m;messageTimer=4f;}
    void Update(){if(messageTimer>0)messageTimer-=Time.deltaTime;}
    void OnGUI(){ if(p==null||s==null)return; title=Make(18,Color.white,TextAnchor.MiddleCenter); small=Make(13,new Color(1,.94,.78f),TextAnchor.MiddleLeft); bar=Make(11,Color.white,TextAnchor.MiddleCenter);
        if(messageTimer>0) GUI.Label(new Rect(Screen.width*.15f,Screen.height*.73f,Screen.width*.7f,70),message,title);
        // stamina/battery micro HUD
        GUI.color=new Color(1,1,1,.45f); GUI.Label(new Rect(24,Screen.height-62,200,20),"STAMINA",small); GUI.Label(new Rect(24,Screen.height-38,200,20),"BATTERY",small); GUI.color=Color.white;
        GUI.Box(new Rect(85,Screen.height-58,110,8),""); GUI.Box(new Rect(85,Screen.height-34,110,8),"");
        GUI.color=new Color(1,1,1,.55f); GUI.DrawTexture(new Rect(86,Screen.height-57,108*p.Stamina/100f,6),Texture2D.whiteTexture); GUI.DrawTexture(new Rect(86,Screen.height-33,108*p.Battery/100f,6),Texture2D.whiteTexture); GUI.color=Color.white;
        float sanityAlpha=Mathf.InverseLerp(58,0,s.Value); if(sanityAlpha>.02f){GUI.color=new Color(.08f,.0f,.0f,sanityAlpha*.18f);GUI.DrawTexture(new Rect(0,0,Screen.width,Screen.height),Texture2D.whiteTexture);GUI.color=Color.white;}
        if(Input.GetKey(KeyCode.E)) GUI.Label(new Rect(Screen.width/2-120,Screen.height/2+28,240,30),"E  INTERAGIR",bar);
        if(inv!=null&&inv.Open){GUI.color=new Color(0,0,0,.85f);GUI.DrawTexture(new Rect(0,0,Screen.width,Screen.height),Texture2D.whiteTexture);GUI.color=Color.white;GUI.Label(new Rect(Screen.width*.36f,80,300,40),"INVENTÁRIO",title);for(int i=0;i<InventorySystem.Slots;i++){float x=Screen.width*.36f+(i%4)*90;float y=150+(i/4)*90;GUI.Box(new Rect(x,y,78,78),i+1+"\n"+inv.Get(i));}}
    }
    GUIStyle Make(int size,Color color,TextAnchor a){var st=new GUIStyle(GUI.skin.label);st.fontSize=size;st.normal.textColor=color;st.alignment=a;st.fontStyle=FontStyle.Bold;return st;}
}

using UnityEngine;

public class PlayerController : MonoBehaviour
{
    CharacterController cc; Camera cam; Light flashlight;
    float yaw, pitch, verticalVel; bool crouched; bool flashlightOn = true;
    float stamina = 100f; float battery = 100f; float headBob; Vector3 camBase;
    public float Stamina => stamina; public float Battery => battery; public bool FlashlightOn => flashlightOn;
    public void Initialize() { cc = GetComponent<CharacterController>(); Cursor.lockState = CursorLockMode.Locked; Cursor.visible = false; }
    public void BindCamera(Camera c) { cam = c; camBase = cam.transform.localPosition; }
    public void BindFlashlight(Light l) { flashlight = l; }

    void Update() {
        if (Input.GetKeyDown(KeyCode.Escape)) { ToggleCursor(); }
        if (Cursor.lockState != CursorLockMode.Locked) return;
        Look(); Move(); HandleFlashlight(); HandleInteraction();
        if (Input.GetKeyDown(KeyCode.I)) FindObjectOfType<InventorySystem>()?.Toggle();
    }
    void Look() {
        float mx = Input.GetAxis("Mouse X") * 2.3f;
        float my = Input.GetAxis("Mouse Y") * 2.3f;
        yaw += mx; pitch = Mathf.Clamp(pitch - my, -88, 88);
        transform.rotation = Quaternion.Euler(0,yaw,0);
        cam.transform.localRotation = Quaternion.Euler(pitch,0,0);
    }
    void Move() {
        bool wantCrouch = Input.GetKey(KeyCode.LeftControl);
        crouched = wantCrouch;
        float targetHeight = crouched ? 1.2f : 1.8f;
        cc.height = Mathf.Lerp(cc.height, targetHeight, Time.deltaTime*12f);
        cc.center = new Vector3(0, cc.height*0.5f, 0);
        Vector3 input = new Vector3(Input.GetAxisRaw("Horizontal"),0,Input.GetAxisRaw("Vertical")); input = Vector3.ClampMagnitude(input,1);
        bool sprint = Input.GetKey(KeyCode.LeftShift) && input.z > 0.1f && !crouched && stamina > 0;
        float speed = sprint ? 6.4f : (crouched ? 1.7f : 3.4f);
        Vector3 move = transform.TransformDirection(input) * speed;
        if (sprint) stamina -= 23f*Time.deltaTime; else stamina += (crouched?27f:11f)*Time.deltaTime;
        stamina = Mathf.Clamp(stamina,0,100);
        if (cc.isGrounded && Input.GetKeyDown(KeyCode.Space) && !crouched) verticalVel = 5.2f;
        verticalVel += Physics.gravity.y * Time.deltaTime;
        move.y = verticalVel;
        cc.Move(move * Time.deltaTime);
        float bobAmount = (input.magnitude>0.1f && cc.isGrounded) ? (sprint?0.07f:0.045f) : 0f;
        if (bobAmount>0) headBob += Time.deltaTime*(sprint?12:8); else headBob = Mathf.Lerp(headBob,0,Time.deltaTime*8);
        cam.transform.localPosition = camBase + new Vector3(0, Mathf.Sin(headBob)*bobAmount, 0);
    }
    void HandleFlashlight() {
        if (Input.GetKeyDown(KeyCode.F) && battery>0.5f) { flashlightOn=!flashlightOn; flashlight.enabled=flashlightOn; }
        if (flashlightOn) battery = Mathf.Max(0,battery-1.8f*Time.deltaTime);
        if (battery<=0) { flashlightOn=false; flashlight.enabled=false; }
    }
    void HandleInteraction() {
        if (!Input.GetKeyDown(KeyCode.E)) return;
        Ray r = new Ray(cam.transform.position, cam.transform.forward);
        if (Physics.Raycast(r,out RaycastHit hit,3f)) hit.collider.GetComponent<Interactable>()?.Interact(this);
    }
    public void AddBattery(float amount) { battery = Mathf.Clamp(battery+amount,0,100); }
    public void SetFlashlight(bool on) { flashlightOn=on && battery>0; flashlight.enabled=flashlightOn; }
    public void ToggleCursor() { bool locked = Cursor.lockState==CursorLockMode.Locked; Cursor.lockState = locked?CursorLockMode.None:CursorLockMode.Locked; Cursor.visible=locked; }
}

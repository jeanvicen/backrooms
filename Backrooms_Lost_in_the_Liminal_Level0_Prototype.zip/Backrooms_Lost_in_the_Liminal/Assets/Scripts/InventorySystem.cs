using UnityEngine;
using System.Collections.Generic;

public class InventorySystem : MonoBehaviour
{
    public const int Slots=8; readonly List<string> items=new List<string>(); public bool Open{get;private set;}
    public bool Has(string id)=>items.Contains(id); public void Add(string id){ if(items.Count<Slots) items.Add(id); }
    public void Toggle(){ Open=!Open; if(Open){Cursor.lockState=CursorLockMode.None;Cursor.visible=true;}else{Cursor.lockState=CursorLockMode.Locked;Cursor.visible=false;} }
    public string Get(int i)=>i>=0&&i<items.Count?items[i]:"—";
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level0Director : MonoBehaviour
{
    public Vector3 SpawnPoint {get; private set;} = new Vector3(2,0.95f,2);
    PlayerController player; SanitySystem sanity; InventorySystem inventory; Transform root; float eventTimer;
    Material wallMat, carpetMat, ceilingMat, darkMat, trimMat;

    public void Connect(PlayerController p, SanitySystem s, InventorySystem i){ player=p;sanity=s;inventory=i; StartCoroutine(AnomalyLoop()); }
    public void Build(){
        root=new GameObject("Level0_Geometry").transform;
        wallMat=Mat(new Color(0.64f,0.55f,0.30f),0.82f); carpetMat=Mat(new Color(0.20f,0.14f,0.09f),1f); ceilingMat=Mat(new Color(0.23f,0.22f,0.18f),0.95f); darkMat=Mat(new Color(0.04f,0.035f,0.03f),1f); trimMat=Mat(new Color(0.45f,0.38f,0.18f),0.7f);
        BuildFloor(); BuildCeiling(); BuildMaze(); BuildLights(); BuildDetails(); BuildExit(); BuildPickups(); BuildNotes(); RenderSettings.fog=true; RenderSettings.fogDensity=0.028f; RenderSettings.fogColor=new Color(0.18f,0.16f,0.11f); RenderSettings.ambientIntensity=0.35f;
    }
    Material Mat(Color c,float smooth){ var m=new Material(Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard")); m.color=c; m.SetFloat("_Smoothness",smooth); return m; }
    void Box(string name, Vector3 pos, Vector3 scale, Material mat, Transform parent=null){ var g=GameObject.CreatePrimitive(PrimitiveType.Cube);g.name=name;g.transform.SetParent(parent?parent:root);g.transform.position=pos;g.transform.localScale=scale;g.GetComponent<Renderer>().sharedMaterial=mat;return; }
    void BuildFloor(){Box("CarpetFloor",new Vector3(18,0,18),new Vector3(36,0.15f,36),carpetMat);}
    void BuildCeiling(){Box("Ceiling",new Vector3(18,4,18),new Vector3(36,0.2f,36),ceilingMat);}
    void BuildMaze(){
        float h=4f,t=0.32f;
        // Outer walls
        Box("Wall_N",new Vector3(18,h/2,35.8f),new Vector3(36,t,h),wallMat); Box("Wall_S",new Vector3(18,h/2,0.2f),new Vector3(36,t,h),wallMat); Box("Wall_W",new Vector3(0.2f,h/2,18),new Vector3(t, h,36),wallMat); Box("Wall_E",new Vector3(35.8f,h/2,18),new Vector3(t,h,36),wallMat);
        float[] xs={5,10,15,20,25,30}; float[] zs={6,12,18,24,30};
        foreach(float x in xs){ Box("Divider",new Vector3(x,h/2,9),new Vector3(t,h,12),wallMat); Box("Divider",new Vector3(x,h/2,27),new Vector3(t,h,12),wallMat); }
        foreach(float z in zs){ Box("Divider",new Vector3(9,h/2,z),new Vector3(12,h,t),wallMat); Box("Divider",new Vector3(27,h/2,z),new Vector3(12,h,t),wallMat); }
        // openings to create loops
        foreach(float x in new[]{5f,15f,25f}) { DestroyAtApprox(new Vector3(x,2,9), new Vector3(1,4,1)); }
    }
    void DestroyAtApprox(Vector3 c, Vector3 half){ foreach(var col in Physics.OverlapBox(c,half/2f)) if(col.gameObject.name=="Divider") Destroy(col.gameObject); }
    void BuildLights(){
        for(int x=2;x<35;x+=4) for(int z=2;z<35;z+=4){
            var go=new GameObject("Fluorescent");go.transform.SetParent(root);go.transform.position=new Vector3(x,3.72f,z);
            var l=go.AddComponent<Light>();l.type=LightType.Area;l.range=7;l.intensity=4.3f;l.color=new Color(1f,0.95f,0.76f); l.shadows=LightShadows.Soft; StartCoroutine(Flicker(l,(x+z)*0.17f));
            Box("CeilingPanel",new Vector3(x,3.86f,z),new Vector3(1.8f,0.06f,0.28f),trimMat,go.transform);
        }
    }
    IEnumerator Flicker(Light l,float seed){ yield return new WaitForSeconds(seed%4f); while(l){ float pulse=Random.value<0.08f?Random.Range(0.05f,0.45f):1f; l.intensity=4.3f*pulse; yield return new WaitForSeconds(Random.Range(0.25f,1.2f)); } }
    void BuildDetails(){
        // pillars and repeating trim for liminal repetition
        for(int x=3;x<35;x+=6) for(int z=3;z<35;z+=6){ Box("Trim",new Vector3(x,0.05f,z),new Vector3(0.7f,0.1f,0.7f),trimMat); }
        var dust=new GameObject("Dust"); var ps=dust.AddComponent<ParticleSystem>(); var main=ps.main; main.loop=true;main.startLifetime=8;main.startSpeed=0.08f;main.startSize=0.02f;main.maxParticles=420; main.startColor=new Color(0.7f,0.65f,0.5f,0.22f); var sh=ps.shape;sh.shapeType=ParticleSystemShapeType.Box;sh.scale=new Vector3(34,4,34);
    }
    void BuildExit(){ var g=GameObject.CreatePrimitive(PrimitiveType.Cube);g.name="EXIT_ELEVATOR";g.transform.position=new Vector3(34.9f,1.9f,33.5f);g.transform.localScale=new Vector3(0.25f,3.8f,3.2f);g.GetComponent<Renderer>().sharedMaterial=Mat(new Color(0.11f,0.015f,0.01f),0.4f);var i=g.AddComponent<Interactable>();i.kind=Interactable.Kind.Exit;i.message="A porta está destrancada. O corredor atrás dela parece errado."; Box("ExitLight",new Vector3(34.6f,2.9f,33.5f),new Vector3(0.08f,0.15f,2.6f),Mat(new Color(0.55f,0.02f,0.01f),0f)); }
    void BuildPickups(){ foreach(Vector3 p in new[]{new Vector3(3,0.35f,7),new Vector3(28,0.35f,22),new Vector3(12,0.35f,31)}){ var g=GameObject.CreatePrimitive(PrimitiveType.Cube);g.name="BatteryPickup";g.transform.position=p;g.transform.localScale=new Vector3(.25f,.45f,.25f);g.GetComponent<Renderer>().sharedMaterial=Mat(new Color(.13f,.17f,.12f),.2f);g.AddComponent<Interactable>().kind=Interactable.Kind.Battery; } }
    void BuildNotes(){ Vector3[] ps={new Vector3(7,1.1f,4),new Vector3(22,1.1f,17),new Vector3(31,1.1f,6)}; string[] tx={"NOTA 03\nNão tente contar as portas. Algumas não estavam aqui quando eu voltei.","GRAVAÇÃO INTERROMPIDA\nSe as luzes piscarem três vezes, fique parado.","AVISO\nO som do zumbido muda quando alguma coisa está perto."}; for(int k=0;k<ps.Length;k++){var g=GameObject.CreatePrimitive(PrimitiveType.Cube);g.transform.position=ps[k];g.transform.localScale=new Vector3(.18f,.26f,.45f);g.GetComponent<Renderer>().sharedMaterial=Mat(new Color(.72f,.64f,.45f),.1f);var it=g.AddComponent<Interactable>();it.kind=Interactable.Kind.Note;it.message=tx[k];}}
    IEnumerator AnomalyLoop(){ while(true){yield return new WaitForSeconds(Random.Range(18f,32f)); if(sanity==null||player==null)continue; if(sanity.Value>62)continue; SpawnAnomaly(); } }
    void SpawnAnomaly(){ var g=GameObject.CreatePrimitive(PrimitiveType.Quad);g.name="LiminalAnomaly";g.transform.position=player.transform.position+player.transform.forward*Random.Range(12,18)+Vector3.up*1.6f;g.transform.LookAt(player.transform.position+Vector3.up*1.2f);var m=Mat(new Color(0.015f,0.0f,0.0f),0);m.SetColor("_EmissionColor",new Color(.3f,0,.0f));m.EnableKeyword("_EMISSION");g.GetComponent<Renderer>().sharedMaterial=m;Destroy(g,2.1f);sanity.AddStress(8);GameUI.ShowMessage("...há alguma coisa no fim do corredor."); }
    public void Escape(){ GameUI.ShowMessage("NÍVEL 0 CONCLUÍDO — a realidade rasga por um instante."); StartCoroutine(EndSequence()); }
    IEnumerator EndSequence(){ yield return new WaitForSeconds(2f); var p=player.GetComponent<PlayerController>(); p.enabled=false; }
}

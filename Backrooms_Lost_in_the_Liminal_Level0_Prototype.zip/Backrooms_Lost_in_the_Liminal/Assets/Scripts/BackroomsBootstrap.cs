using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackroomsBootstrap : MonoBehaviour
{
    public static BackroomsBootstrap Instance { get; private set; }
    public PlayerController Player { get; private set; }
    public SanitySystem Sanity { get; private set; }
    public InventorySystem Inventory { get; private set; }
    public Level0Director Level { get; private set; }

    void Awake() {
        if (Instance != null) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void Start() {
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = 120;
        Screen.SetResolution(Mathf.Min(Screen.currentResolution.width, 1920), Mathf.Min(Screen.currentResolution.height, 1080), true);
        BuildRuntime();
    }

    void BuildRuntime() {
        var levelGo = new GameObject("LEVEL_0_THE_LOBBY");
        Level = levelGo.AddComponent<Level0Director>();
        Level.Build();

        var playerGo = new GameObject("Player");
        playerGo.transform.position = Level.SpawnPoint;
        var cc = playerGo.AddComponent<CharacterController>();
        cc.height = 1.8f; cc.radius = 0.28f; cc.stepOffset = 0.35f; cc.slopeLimit = 50f;
        Player = playerGo.AddComponent<PlayerController>();
        Player.Initialize();

        Sanity = playerGo.AddComponent<SanitySystem>();
        Inventory = playerGo.AddComponent<InventorySystem>();

        SetupCamera(playerGo);
        SetupUI();
        Level.Connect(Player, Sanity, Inventory);
    }

    void SetupCamera(GameObject playerGo) {
        var camGo = new GameObject("PlayerCamera");
        camGo.transform.SetParent(playerGo.transform, false);
        camGo.transform.localPosition = new Vector3(0, 0.72f, 0);
        var cam = camGo.AddComponent<Camera>();
        cam.fieldOfView = 74f;
        cam.nearClipPlane = 0.02f;
        cam.farClipPlane = 120f;
        cam.depthTextureMode = DepthTextureMode.Depth;
        var listener = camGo.AddComponent<AudioListener>();
        Player.BindCamera(cam);
        var lightGo = new GameObject("Flashlight");
        lightGo.transform.SetParent(camGo.transform, false);
        lightGo.transform.localPosition = new Vector3(0.15f,-0.05f,0.2f);
        var spot = lightGo.AddComponent<Light>();
        spot.type = LightType.Spot;
        spot.range = 28f;
        spot.spotAngle = 62f;
        spot.innerSpotAngle = 35f;
        spot.intensity = 8f;
        spot.shadows = LightShadows.Soft;
        Player.BindFlashlight(spot);
    }

    void SetupUI() {
        var ui = new GameObject("GameUI");
        ui.AddComponent<GameUI>();
    }
}

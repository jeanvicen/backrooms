using UnityEngine;

public class SanitySystem : MonoBehaviour
{
    float sanity=100f; float spikeTimer; public float Value=>sanity;
    public void AddStress(float amount){ sanity=Mathf.Clamp(sanity-amount,0,100); spikeTimer=1.2f; }
    void Update(){
        var p=GetComponent<PlayerController>();
        if(p!=null && !p.FlashlightOn) sanity-=0.55f*Time.deltaTime;
        else sanity+=0.12f*Time.deltaTime;
        sanity=Mathf.Clamp(sanity,0,100); spikeTimer=Mathf.Max(0,spikeTimer-Time.deltaTime);
    }
    public float Distortion(){ return Mathf.InverseLerp(55,0,sanity); }
}

using UnityEngine;

public class Interactable : MonoBehaviour
{
    public enum Kind { Battery, Note, Exit }
    public Kind kind; public string message; bool used;
    public void Interact(PlayerController player){
        if(used) return;
        var inv=player.GetComponent<InventorySystem>(); var sanity=player.GetComponent<SanitySystem>();
        switch(kind){
            case Kind.Battery: player.AddBattery(35); inv.Add("Bateria"); used=true; Destroy(gameObject); break;
            case Kind.Note: GameUI.ShowMessage(message); sanity.AddStress(2); used=true; break;
            case Kind.Exit: FindObjectOfType<Level0Director>()?.Escape(); break;
        }
    }
}

# Backrooms: Lost in the Liminal — Level 0 Prototype

Unity 2024.2 + URP prototype focused on immersive Level 0 exploration.

## Included
- FPS movement: WASD, mouse, sprint, crouch, jump
- Smooth head bob + breathing sway
- Flashlight (F) with battery drain/recharge pickups
- Interaction raycast (E)
- Sanity system with visual/audio stress effects
- 8-slot inventory scaffold (I)
- Procedural Level 0 office maze
- Fluorescent flicker, fog, dust particles, ambient hum
- Liminal anomaly event that appears/distorts when sanity falls
- Exit/objective loop: find the red-lit elevator door
- Pause with ESC
- Runtime UI built without external assets

## Open
1. Open this folder in Unity Hub using Unity 2024.2+.
2. Let the editor import packages.
3. Open `Assets/Scenes/Level0.unity`.
4. Press Play.

The Editor setup script generates URP assets automatically on import. No paid assets are required.

## Controls
WASD Move | Shift Sprint | Ctrl Crouch | Space Jump | Mouse Look | E Interact | F Flashlight | I Inventory | Esc Pause
